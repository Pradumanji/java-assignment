 package geoshapes;
public class Sphere{
  public  void perimeter (int radius)
   {
    System.out.println("Perimeter of Sphere : "+ 4*radius*3.14);
   }
  public  void area(int radius)
   {
    System.out.println("Area of Sphere "+ 3.14*radius*radius);
   }
}