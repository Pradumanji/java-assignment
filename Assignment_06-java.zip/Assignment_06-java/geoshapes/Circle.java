package geoshapes;
public class Circle {
   
   public void perimeter (int radius)
   {
    System.out.println("Perimeter of circle : "+ 2*radius*3.14);
   }
   public void area(int radius)
   {
    System.out.println("Area of Circle "+ 3.14*radius*radius);
   }
}