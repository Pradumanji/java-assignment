 package geoshapes;
public class Rectangle{
  public  void perimeter (int height, int width)
   {
    System.out.println("Perimeter of Rectangle : "+ 2*(height+width));
   }
   public void area(int height, int width)
   {
    System.out.println("Area of Rectangle "+ height*width);
   }
}
